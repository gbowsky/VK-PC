<?php
namespace app\forms;

use std, gui, framework, app;


class gifViewer extends AbstractForm
{
    function call_gif_view($photo_url)
    {
        $this->show();
        $this->scale = 1;
        AdvancedVK::cache($photo_url,$this->image);
    }
}