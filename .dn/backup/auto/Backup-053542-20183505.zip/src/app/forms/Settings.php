<?php
namespace app\forms;

use std, gui, framework, app;


class Settings extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        fs::clean('./cache/');
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        SimpleVK::clearAuth();
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $GLOBALS['content'] = 'Settings';
    }


}
