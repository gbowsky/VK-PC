<?php
namespace app\forms;

use std, gui, framework, app;


class fatal extends AbstractForm
{

}