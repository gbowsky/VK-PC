<?php
namespace app\forms;

use std, gui, framework, app;


class Authentication extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        if (SimpleVK::createAuth($this->edit->text, $this->passwordField->text) == true)
        {
            app()->showForm(MainForm);
            app()->hideForm(Authentication);
            $this->free();
        }    
        else 
        {
            $this->toast('Error');
        }
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        if (SimpleVK::checkAuth() == true)
        {
            $this->loadForm(MainForm);
        }
    }

}
