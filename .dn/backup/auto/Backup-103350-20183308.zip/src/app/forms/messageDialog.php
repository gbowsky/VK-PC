<?php
namespace app\forms;

use std, gui, framework, app;


class messageDialog extends AbstractForm
{

    public $offset;

    function load_messages($id)
    {
        $info = json_decode($id,1);
        $messages = SimpleVK::Query('messages.getHistory', ['peer_id'=>$info['id'],'count'=>10]);
        foreach ($messages['response']['items'] as $msg_object)
        {
           $this->render_message($msg_object);
        }
    }
    
    function render_message($msg_object)
    {
        $source = $GLOBALS['users'][$msg_object['from_id']];
        $message_main = new UXHBox;
        $message_photo = new UXImageView;
        $message_photo->size = [40,40];
        AdvancedVK::cache($source['photo_50'], $message_photo,true);
        $message_main->add($message_photo);
        $message_box = new UXVBox;
        $peer_name = new UXLabel($source['name']);
        $message_box->add($peer_name);
        $message_main->add($message_box);
        $this->listView->items->add($message_main);
        if (isset($msg_object['text']))
        {
            $message_text = new UXLabel($msg_object['text']);
            $message_box->add($message_text);
        }
        if (isset($msg_object['attachments']))
        {
            $message_box->add(AdvancedVK::news_attachments($msg_object['attachments'], 530));
        }
        $message_info = new UXHBox;
    }

}