<?php
namespace app\forms;

use std, gui, framework, app;


class on2faForm extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        if (SimpleVK::createAuth($GLOBALS['2fa_login'], $GLOBALS['2fa_pass'],$GLOBALS['2fa_save'],$GLOBALS['2fa_ext'],$this->passwordField->text) == true)
        {
            app()->showForm(MainForm);
            app()->hideForm(on2faForm);
            $this->free();
        }    
        else 
        {
            $this->toast('Error');
        }
    }
    
    public function on2faStart($login, $password, $arr, $save, $extapi)
    {
        $GLOBALS['2fa_login'] = $login;
        $GLOBALS['2fa_pass'] = $password;
        $GLOBALS['2fa_save'] = $save;
        $GLOBALS['2fa_ext'] = $extapi;
        $GLOBALS['2fa_key'] = $arr['validation_sid'];
        if ($arr['validation_type'] == '2fa_app')
        {
            $this->labelAlt->text = 'Code sent via app';
        }
        else 
        {
            $this->labelAlt->text = 'Code sent via sms '.$arr['phone_mask'];
        }
    }

}
