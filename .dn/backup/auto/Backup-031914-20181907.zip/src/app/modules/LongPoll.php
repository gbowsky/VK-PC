<?php
namespace app\modules;

use std, gui, framework, app;


class LongPoll extends AbstractModule
{

    public static $access_token;

    public static function init(){
        self::$access_token=SimpleVK::$accessToken;
        $data=SimpleVK::Query('messages.getLongPollServer', ['use_ssl'=>1]);
        $server = $data['response']['server'];
        $key = $data['response']['key'];
	$ts = $data['response']['ts'];

        c=new Thread(function() use($data, $server, $key, $ts){
            while(true){
	        $ch = new jURL("{$server}?act=a_check&key={$key}&ts={$ts}&wait=25");
                $resp = $ch->exec();
		$ch->close();
		$resp=json_decode($resp,1);
		if(array_key_exists('failed', $resp)){
		    switch($resp['failed']){
			case 1:
			$ts = $resp['ts'];
			continue;
			case 2:
			$data = SimpleVK::Query('messages.getLongPollServer', ['use_ssl'=>1]);
			$ch->close();
			$key = $data['response']['key'];
			continue;
			case 3:
			$data = SimpleVK::Query('messages.getLongPollServer', ['use_ssl'=>1]);
			$ch->close();
			$key = $data['response']['key'];
			$ts = $data['response']['ts'];
			continue;
		    }
	        }
	        $ts = $resp['ts'];

                if(count($resp['updates'])>0){
		    foreach ($resp['updates'] as $id => $upd) {
                        if($upd[0]==4){
                            var_dump($upd);
                        }    
                    }
                }
    
            }
        });
    }
}