<?php
namespace app\forms;

use std, gui, framework, app;


class about_modal extends AbstractForm
{

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->hide();
        $this->free();
    }

}
