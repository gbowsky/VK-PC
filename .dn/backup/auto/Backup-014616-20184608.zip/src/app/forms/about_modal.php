<?php
namespace app\forms;

use std, gui, framework, app;


class about_modal extends AbstractForm
{

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->hide();
        $this->free();
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        browse('https://vk.com/gbowsky');
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        browse('https://vk.com/unfox_vk');
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
        browse('https://vk.com/vkpccl');
    }

}
