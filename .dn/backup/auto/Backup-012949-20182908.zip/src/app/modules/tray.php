<?php
namespace app\modules;

use script\SystemTrayScript;
use php\desktop\SystemTray;
use std, gui, framework, app;


class tray extends AbstractModule
{

}
