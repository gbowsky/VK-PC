<?php
namespace app\forms;

use std, gui, framework, app;


class Dialogs extends AbstractForm
{

    function load_dialogs()
    {
        $dialogs_resp = SimpleVK::Query('messages.getConversations');
    }
    
    
    function render_dialog()
    {
        
    }
}