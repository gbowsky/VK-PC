<?php
namespace app\forms;

use std, gui, framework, app;


class about_modal extends AbstractForm
{

}