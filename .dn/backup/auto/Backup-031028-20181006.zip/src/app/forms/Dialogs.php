<?php
namespace app\forms;

use std, gui, framework, app;


class Dialogs extends AbstractForm
{
    public $offset = 20,$max_users;

    /**
     * @event listView.scroll-Down 
     */
    function doListViewScrollDown(UXScrollEvent $e = null)
    {    
        if ($this->offset < $this->max_users)
        {
            $a = $this->listView->items->count;
            $this->offset = $this->offset + 20;
            $this->load_dialogs();
            $this->listView->scrollTo($a-1);
        }
    }

    function load_dialogs()
    {
        $dialogs_resp = SimpleVK::Query('messages.getConversations', ['filter'=>'all', 'extended'=>true,'fields'=>'photo_50','count'=>$this->offset]);
        $this->max_users = $dialogs_resp['response']['count'];
        file_put_contents('messages.txt', json_encode($dialogs_resp));
        $this->render_dialog($dialogs_resp, 530);
    }
    
    
    function render_dialog($dialogs_resp, $pref_width)
    {
        $this->listView->hide();
        $this->listView->items->clear();
        foreach ($dialogs_resp['response']['items'] as $dialog)
        {
            $source = $this->get_com_user_id($dialog['conversation']['peer']['id'], $dialogs_resp, $dialog);
            $dialog_image = new UXImageView;
            $dialog_image->size = [40,40];
            AdvancedVK::cache($source['photo_50'], $dialog_image, true);
            $dialog_name = new UXLabel($source['name']);
            $dialog_date = new UXLabel(AdvancedVK::msg_date($dialog['last_message']['date']));
            $dialog_data_name = new UXHBox([$dialog_name,$dialog_date]);
            $msg_source = $this->get_com_user_id($dialog['last_message']['from_id'], $dialogs_resp,$dialog);
            $dialog_last_message = new UXLabel(trim($msg_source['name'].' : '.$dialog['last_message']['text']));
            $dialog_last_message->maxWidth = $pref_width;
            $dialog_last_message->maxHeight = 60;
            $dialog_data = new UXVBox([$dialog_data_name,$dialog_last_message]);
            $dialog_box = new UXHBox([$dialog_image,$dialog_data]);
            file_put_contents('user_obj.txt', json_encode($msg_source));
            file_put_contents('messagesa.txt', json_encode($source));
            $this->listView->items->add($dialog_box);
            
            $dialog_box->classesString='dialog_box';
            $dialog_data->classesString='dialog_data';
            $dialog_name->classesString='dialog_name';
            $dialog_date->classesString='dialog_date';
            $dialog_last_message->classesString='dialog_last_message';
        }
        $this->listView->show();
    }
    
    function get_com_user_id($id, $conv_obj, $dlg)
    {
        if ($id > 2000000000)
        {
            $dlg['conversation']['chat_settings']['name'] = $dlg['conversation']['chat_settings']['title'];
            $dlg['conversation']['chat_settings']['photo_50'] = $dlg['conversation']['chat_settings']['photo']['photo_50'];
            return $dlg['conversation']['chat_settings'];
        }
        else
        {
           if ($id < 0)
           {
               foreach ($conv_obj['response']['groups'] as $grp_obj)
               {
                   if ($id == $grp_obj['id']*-1)
                   {
                       return $grp_obj;
                   }
               }    
           } 
           else 
           {
               foreach ($conv_obj['response']['profiles'] as $prof_obj)
               {
                   if ($prof_obj['id'] == $id) 
                   {
                       if ($GLOBALS['user']['id'] == $prof_obj['id'])
                       {
                           $prof_obj['name'] = 'Вы';
                       }
                       else
                       {
                           $prof_obj['name'] = $prof_obj['first_name'].' '.$prof_obj['last_name'];
                       }
                       return $prof_obj;    
                   }    
               }   
           }
        }
    }
}
